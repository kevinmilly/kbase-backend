const USER = "kevinthecoder"
const PW = "8501RidgewoodAve"
const CLUSTER = "@kbasecluster.mcypg.mongodb.net/kbase?retryWrites=true&w=majority"

//Google Search
const GAPIKEY = "AIzaSyDnNGMM9G7dTLQsvRCEBdpcIin-uQKMiI8"
const id = "753d679ea8f20b579";

module.exports = {
    pw: PW,
    user: USER,
    cluster: CLUSTER,
    gapikey:GAPIKEY,
    id:id
  };